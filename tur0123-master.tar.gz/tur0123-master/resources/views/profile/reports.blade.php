@extends('layouts.profile')
@section('main')
    <h1>My reports</h1>
    @if(empty($reports))
        @include('profile/components/checkout-modal-button', ['text' => "You don't have any reports"])
    @else
        <ol>
            @foreach($reports as $report)
                <li>
                    <a href="{{ url('/reports', $report->id) }}"><i class="fa fa-download"></i>{{$report->file_name}}
                    </a>
                </li>
            @endforeach
        </ol>
    @endif
@endsection