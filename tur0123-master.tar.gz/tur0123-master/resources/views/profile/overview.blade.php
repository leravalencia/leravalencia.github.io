@extends('layouts.profile')
@section('main')
    @include('profile.components.header-with-buy-button', ['header'=>'Overview'])
    <div class="map_holder top-space bottom-space" id="js-overview-holder">
        <div class='tableauPlaceholder' id='viz1518604820259' style='position: relative'>
            <noscript><a href='#'><img alt='2_ZIPcodeMap '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview1_1&#47;2_ZIPcodeMap&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='Overview1_1&#47;2_ZIPcodeMap'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview1_1&#47;2_ZIPcodeMap&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>

        <div class='tableauPlaceholder' id='viz1518605039150' style='position: relative'>
            <noscript><a href='#'><img alt='3_HLcount_Carrs+Owners '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview2&#47;3_HLcount_CarrsOwners&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='Overview2&#47;3_HLcount_CarrsOwners'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview2&#47;3_HLcount_CarrsOwners&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>
        <div class='tableauPlaceholder' id='viz1518605127760' style='position: relative'>
            <noscript><a href='#'><img alt='5_Car_Quantity '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview3&#47;5_Car_Quantity&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='Overview3&#47;5_Car_Quantity'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ov&#47;Overview3&#47;5_Car_Quantity&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>
    </div>
    <script type='text/javascript'>
      let width = document.getElementById('js-overview-holder').offsetWidth;
      var divElement = document.getElementById('viz1518604820259');
      var vizElement = divElement.getElementsByTagName('object')[0];
      vizElement.style.width = width + 'px';
      vizElement.style.height = '847px';
      var scriptElement = document.createElement('script');
      scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
      vizElement.parentNode.insertBefore(scriptElement, vizElement);

      var divElementTwo = document.getElementById('viz1518605039150');
      var vizElementTwo = divElementTwo.getElementsByTagName('object')[0];
      vizElementTwo.style.width = width + 'px';
      vizElementTwo.style.height = '847px';
      vizElementTwo.parentNode.insertBefore(scriptElement, vizElementTwo);


      var divElementThree = document.getElementById('viz1518605127760');
      var vizElementThree = divElementThree.getElementsByTagName('object')[0];
      vizElementThree.style.width = width + 'px';
      vizElementThree.style.height = '847px';
      vizElementThree.parentNode.insertBefore(scriptElement, vizElementThree);
    </script>
@endsection