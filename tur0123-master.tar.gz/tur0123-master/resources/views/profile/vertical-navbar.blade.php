<aside class="ink-navigation">
    <ul class="menu vertical white">
        <li {{{ (Request::is('world') ? 'class=active' : '') }}} >
            <a href="{{ url('/world') }}">World Map</a>
        </li>
    </ul>
    <h5 class="small top-space">
        Sample {{env('APP_NAME')}} Data report
    </h5>
    <ul class="menu vertical white">
        <li {{{ (Request::is('overview') ? 'class=active' : '') }}} >
            <a href="{{ url('/overview') }}">
                <span class="db">Overview</span>
            </a>
        </li>
        <li {{{ (Request::is('occupancy') ? 'class=active' : '') }}} >
            <a href="{{ url('/occupancy') }}">
                <span class="db">Occupancy</span>
            </a>
        </li>
        <li {{{ (Request::is('pricing') ? 'class=active' : '') }}} >
            <a href="{{ url('/pricing') }}">
                <span class="db">Pricing</span>
            </a>
        </li>
        <li {{{ (Request::is('rental') ? 'class=active' : '') }}} >
            <a href="{{ url('/rental') }}">
                <span class="db">Rental Analysis</span>
            </a>
        </li>
        <li {{{ (Request::is('top') ? 'class=active' : '') }}} >
            <a href="{{ url('/top') }}">
                <span class="db">TOP cars</span>
            </a>
        </li>
        <li {{{ (Request::is('revenue') ? 'class=active' : '') }}} >
            <a href="{{ url('/revenue') }}">
                <span class="db">Revenue</span>
            </a>
        </li>
        <li {{{ (Request::is('reports') ? 'class=active' : '') }}} >
            <a href="{{ url('/reports') }}">
                <span class="db">Your Reports</span>
            </a>
        </li>
        @if (\auth()->user()->partner || \auth()->user()->admin)
            <li {{{ (Request::is('partner') ? 'class=active' : '') }}} >
                <a href="{{ url('/partner') }}">
                    <span class="db">Partner</span>
                </a>
            </li>
        @endif
    </ul>
</aside>
