<div class="ink-flex vertical align-center push-middle">
    <div class="large">$39.99</div>
    <button class="paypal-buy-button blue push-right" id="js-order-report-show-modal">
        @if(isset($text))
            {{$text}}
        @else
            <img src="{{ \url('/img/design/paypal_ico.png') }}">
            BUY YOUR AREA REPORT NOW
        @endif
    </button>
    <img src="{{ \url('/img/design/cc-badges-ppmcvdam.png') }}"
         alt="Pay with PayPal or a debit/credit card"
         class="maw150px quarter-top-space">
</div>
<div id="js-order-report-modal" class="dn">
    <h2 class="align-center">Order report to get the full data</h2>
    <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" class="align-center">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="3PB5W9H7ZSUHA">
        <input type="hidden" name="email" value="{{ \auth()->user()->email }}">
        <input type="hidden" name="user_id" value="{{ \auth()->user()->id }}">
        <input type="hidden" name="return" value="{{ \url('/payment/success') }}">
        <table class="all-100">
            <tr>
                <td><input type="hidden" name="on0" value="Zip Code/Country/Make/Model">Zip Code/Country/Make/Model</td>
            </tr>
            <tr class="all-100">
                <td class="all-100">
                    <input type="text"
                           name="os0"
                           maxlength="200"
                           title="Zip Code/Country/Make/Model"
                           class="all-100">
                </td>
            </tr>
        </table>
        <button name="submit"
                type="submit"
                class="push-center paypal-buy-button w350px">
            <img src="{{ url('/img/design/paypal_ico.png') }}">
            <span>Enter your Zip Code and Buy Now</span>
        </button>
        {{--<input type="image"--}}
        {{--class="push-center"--}}
        {{--src="https://www.paypalobjects.com/en_US/i/btn/btn_cart_LG.gif"--}}
        {{--border="0"--}}
        {{--name="submit"--}}
        {{--alt="PayPal - The safer, easier way to pay online!">--}}
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
    </form>
    <div class="quarter-top-space align-center">
        Report will be delivered within 24 hours after your payment to your e-mail and to your &quot;Reports&quot;
        folder
    </div>
</div>