<div class="column-group js_sb">
    <h1>{{ $header }}</h1>
    <div class="push-right ">@include('profile/components/checkout-modal-button')</div>
</div>