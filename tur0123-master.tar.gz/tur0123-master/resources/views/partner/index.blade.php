@extends('layouts.profile')
@section('main')
    <h1 class="align-center">Partner room</h1>
    <h2 class="quarter-top-space">Your partner links</h2>
    @if($user->affiliateLinks->isEmpty())
        There are no links for you. Write to support
    @else
        <table class="ink-table">

            @foreach($user->affiliateLinks as $link)
                <tr>
                    <td><a href="{{url('a',$link->link)}}">{{url('a',$link->link)}}</a></td>
                    <td>
                        <input type="text"
                               class="all-100 quarter-padding"
                               value="{{url('a',$link->link)}}"
                               title="link">
                    </td>
                </tr>
            @endforeach

        </table>

        <h2 class="quarter-top-space">Your links stats</h2>
        <table class="ink-table">
            <thead>
            <tr>
                <th>link</th>
                <th>views</th>
                <th>registers</th>
            </tr>
            </thead>

            @foreach($user->affiliateLinks as $link)
                <tr>
                    <td>{{url('a',$link->link)}}</td>
                    <td>{{$link->views}}</td>
                    <td>{{$link->registers}}</td>
                </tr>
            @endforeach

        </table>

        @if ($affiliates->isNotEmpty())
            <h3 class="half-top-space">Registered users</h3>
            <table class="ink-table">
                <thead>
                <tr>
                    <th>email</th>
                    <th>Register date</th>
                </tr>
                </thead>
                <tbody>

                @foreach($affiliates as $affiliate)
                    <tr>
                        <td>{{$affiliate->email}}</td>
                        <td>{{$affiliate->created_at->format('m/d/Y  H:i:s')}}</td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        @endif

        @if($reports->isNotEmpty())
            <h3 class="half-top-space">Reports</h3>
            <table class="ink-table">
                <thead>
                <tr>
                    <th>Report</th>
                    <th>Buy date</th>
                </tr>
                </thead>
                <tbody>

                @foreach($reports as $report)
                    <tr>
                        <td>{{$report->file_name}}</td>
                        <td>{{$report->created_at->format('m/d/Y H:i:s')}}</td>
                    </tr>
                @endforeach

                </tbody>
            </table>
        @endif
    @endif
    <div class="bottom-space"></div>
@endsection