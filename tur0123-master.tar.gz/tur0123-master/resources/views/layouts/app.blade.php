<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TURO Data, Insights, and Analytics - {{env('APP_NAME')}}</title>
    <meta name="description" content="TURO data and insights to succeed in a car sharing economy">
    <meta name="author" content="{{env('APP_NAME')}}">
    <meta property="og:url" content="{{ url('/') }}">
    <meta property="og:site_name" content="{{env('APP_NAME')}}">
    <meta property="og:title" content="TURO data,  insights and analytics to succeed in a car sharing economy">
    <meta property="og:description" content="TURO data and insights to succeed in a car sharing economy">
    <meta property="og:type" content="website">
    <meta property="og:image"
          content="{{ asset('/img/bg/01/Turo0123_white.jpg') }}">
    <meta property="og:locale" content="en_US">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="{{env('APP_NAME')}}">
    <meta name="twitter:description" content="TURO data, insights and analytics to succeed in a car sharing economy">
    <meta name="twitter:image"
          content="{{ asset('/img/bg/01/Turo0123_white.jpg') }}">
    <meta name="twitter:image:alt" content="{{env('APP_NAME')}}">
    <link rel="stylesheet" href="{{ mix('/css/app.css') }}">
</head>
<body class="all-100">
    <div class="wrap">
        @include('profile.header')
        @yield('content')
        <div class="push"></div>
    </div>
    @include('profile.footer')
<script src="{{ asset('js/app.js') }}"></script>
<script type="text/javascript" src="//script.crazyegg.com/pages/scripts/0072/9058.js" async="async"></script>
</body>
</html>
