@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="ink-grid">
            <div class="column-group horizontal-gutters top-space">
                <div class="xlarge-20 large-25 medium-25 small-100 tiny-100">
                    @include('profile.vertical-navbar')
                </div>
                <div class="xlarge-80 large-75 medium-75 small-100 tiny-100">
                    @yield('main')
                </div>
            </div>
        </div>
    </div>
@endsection