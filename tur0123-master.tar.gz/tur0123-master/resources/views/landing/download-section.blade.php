<div class="widget widget-download widget-download-download-1">
    <section
            class="x-el x-el-section px_-text-transform-uppercase px_-bc-rgb255__255__255 px_-pt-80px px_-pb-80px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
        <div data-ux="Container"
             class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase px_-mb-30px px_-ff-_Archivo_Black___arial__sans-serif
                          px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <h2 class="x-el x-el-h2 px_-text-transform-uppercase
                        px_-overflow-wrap-break-word px_-word-wrap-break-word
                            px_-word-break-break-word px_-fs-23
                            px_-c-rgb129__117__109 px_-fw-400 px_-lh-1p25
                            px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-40px
                            px_-ff-_Archivo_Black___arial__sans-serif px_-overflow-hidden
                             px_-text-align-center _mdpx_-text-align-center _mdpx_-fs-26
                             _lgpx_-fs-28 x-d-ux x-d-aid x-d-route">
                            <span data-ux="Element"
                                  class="x-el x-el-span px_-text-transform-uppercase px_-d-inline-block px_-position-relative px_-c-inherit px_-max-width-80P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-23 px__before-right-100P px__before-mr-20px px__before-content-__ px__before-h-1px px__before-mt--1px px__before-b-currentColor px__before-position-absolute px__before-top-p75em px__before-w-100vw px__before-d-block px__after-left-100P px__after-ml-20px px__after-content-__ px__after-h-1px px__after-mt--1px px__after-b-currentColor px__after-position-absolute px__after-top-p75em px__after-w-100vw px__after-d-block _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux">San Francisco Sample Report (Dec 17)</span>
                </h2></div>
            <div data-ux="Grid"
                 class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-ml-16p666666666666664P _mdpx_-flex-basis-66p66666666666666P _mdpx_-max-width-66p66666666666666P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
                    <a data-ux="Link" target="_blank" display="block"
                       href="{{$reportLink}}"
                       class="x-el x-el-a px_-text-transform-none px_-overflow-wrap-break-word px_-fs-16 px_-fw-400 px_-c-rgb121__109__102 px_-text-decoration-none px_-d-inline px_-cursor-pointer px_-ff-_Montserrat___arial__sans-serif px__hover-c-rgb108__97__91 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                        <div data-ux="Block"
                             class="x-el x-el-div px_-text-transform-none px_-mb-2px px_-d-flex
                                     px_-justify-content-space-between px_-align-items-center px_-pt-12px px_-pb-12px
                                     px_-pl-20px px_-pr-20px px_-bc-rgb246__246__246 px_-ff-_Montserrat___arial__sans-serif
                                     px_-fs-16 px__hover-bc-rgba0_0_0_p05__important _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                    <span class="x-el x-el-span px_-text-transform-none px_-overflow-wrap-break-word
                                    px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16
                                    px_-fw-700 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                                    px_-max-width-90P _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route">
                                        {{env('APP_NAME')}}_9410_San Franc (pdf)
                                    </span>
                            <div class="x-el x-el-div px_-text-transform-none px_-d-flex px_-align-items-center
                                    px_-justify-content-space-between px_-ml-12px px_-ff-_Montserrat___arial__sans-serif
                                    px_-fs-16 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                <svg viewBox="0 0 64 64" fill="currentColor"
                                     class="x-el x-el-svg px_-text-transform-none px_-c-rgb121__109__102
                                             px_-d-inline-block px_-w-16px px_-h-16px px_-mr-10px
                                             px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                    <svg viewBox="0 0 26 26">
                                        <path d="M20,22c0-0.5-0.5-1-1-1s-1,0.5-1,1s0.5,1,1,1S20,22.5,20,22z M24,22c0-0.5-0.5-1-1-1s-1,0.5-1,1 s0.5,1,1,1S24,22.5,24,22z M26,18.5v5c0,0.8-0.7,1.5-1.5,1.5h-23C0.7,25,0,24.3,0,23.5v-5C0,17.7,0.7,17,1.5,17h7.3l2.1,2.1 c0.6,0.6,1.3,0.9,2.1,0.9s1.5-0.3,2.1-0.9l2.1-2.1h7.2C25.3,17,26,17.7,26,18.5z M20.9,9.6c0.2,0.4,0.1,0.8-0.2,1.1l-7,7 C13.5,17.9,13.3,18,13,18s-0.5-0.1-0.7-0.3l-7-7C5,10.4,4.9,10,5.1,9.6C5.2,9.2,5.6,9,6,9h4V2c0-0.5,0.5-1,1-1h4c0.5,0,1,0.5,1,1v7 h4C20.4,9,20.8,9.2,20.9,9.6z"></path>
                                    </svg>
                                </svg>
                                <span class="x-el x-el-span px_-text-transform-none
                                        px_-overflow-wrap-break-word px_-word-wrap-break-word
                                        px_-word-break-break-word px_-c-rgb121__109__102
                                        px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0
                                        px_-ff-_Montserrat___arial__sans-serif
                                        _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid">
                                            Download
                                        </span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
</div>