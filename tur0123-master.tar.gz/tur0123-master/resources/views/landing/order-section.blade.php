<section class="x-el
                x-el-section
                px_-text-transform-uppercase
                px_-bc-rgb255__255__255
                px_-pt-80px
                px_-pb-80px
                px_-ff-_Archivo_Black___arial__sans-serif
                px_-fs-14
                _mdpx_-fs-14
                _lgpx_-fs-14
                x-d-ux">
    <div class="x-el
                x-el-div
                px_-text-transform-uppercase
                px_-ml-auto
                px_-mr-auto
                px_-pl-20px
                px_-pr-20px
                px_-max-width-100P
                px_-ff-_Archivo_Black___arial__sans-serif
                px_-fs-14
                _smpx_-w-728px
                _mdpx_-w-984px
                _mdpx_-fs-14
                _lgpx_-w-1160px
                _lgpx_-fs-14
                x-d-ux">
        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box
                            px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-ff-_Archivo_Black___arial__sans-serif
                            px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-0P px_-p-0_10px_0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-ml-8p333333333333332P _mdpx_-flex-basis-83p33333333333334P _mdpx_-max-width-83p33333333333334P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                            <img
                                    src="{{ url('/img/design/phone.jpg') }}"
                                    class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-30px px_-d-block px_-max-height-500 px_-m-0_auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-mb-0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
                        </div>
                    </div>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-text-align-center px_-mt-20px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-mt-0 _mdpx_-text-align-left _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <h2
                            class="x-el
                                   x-el-h2
                                   px_-text-transform-none
                                   px_-overflow-wrap-break-word
                                   px_-word-wrap-break-word
                                   px_-word-break-break-word
                                   px_-fs-25
                                   px_-c-rgb27__27__27
                                   px_-fw-400
                                   px_-lh-1p125
                                   px_-ml-0
                                   px_-mr-0
                                   px_-mt-0
                                   px_-mb-0
                                   px_-ff-_Montserrat___arial__sans-serif
                                   _mdpx_-fs-30
                                   _lgpx_-fs-31
                                   x-d-ux
                                   x-d-aid
                                   x-d-route">
                            ZIP code + 15 miles report
                        </h2>
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-mt-5px px_-mb-12px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <p class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                    px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb129__117__109 px_-fs-20
                                    px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                                    px_-d-inline-block _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                                $39.99
                            </p>
                            {{--     <p class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                         px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-12 px_-fw-400
                                          px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px_-d-inline-block
                                          px_-ml-10px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-route">
                                     ($0.00 shipping)
                                 </p>--}}
                        </div>
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block
                                px_-pt-20px px_-pb-20px
                                px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <form target="paypal"
                                  action="https://www.paypal.com/cgi-bin/webscr"
                                  method="post"
                                  class="x-el
                                          x-el-form
                                          px_-text-transform-uppercase
                                          px_-mb-0
                                          px_-ff-_Archivo_Black___arial__sans-serif
                                          px_-fs-14 _mdpx_-fs-14
                                          _lgpx_-fs-14
                                          tac
                                          x-d-ux">
                                <input type="text"
                                       placeholder="Zip Code/Country/Make/Model"
                                       title="Zip Code/Country/Make/Model"
                                       class="x-el
                                       x-el-input
                                       px_-text-transform-none
                                                px_-bc-rgb255__255__255
                                                px_-border-color-rgb218__218__218 px_-c-rgb71__71__71
                                                px_-fs-12 px_-fw-400 px_-border-width-1px
                                                w340px
                                                mb1rem
                                                 px_-ff-_Montserrat___arial__sans-serif
                                                px_-border-radius-4px px_-pt-10px px_-pb-10px px_-pl-10px
                                                px_-pr-10px px_-border-style-solid
                                                px___placeholder-c-rgba71__71__71__0p7
                                                px__focus-outline-none
                                                px___-webkit-input-placeholder-c-rgba71__71__71__0p7
                                                px__-ms-input-placeholder-c-rgba71__71__71__0p7
                                                _mdpx_-fs-14
                                                _lgpx_-fs-14
                                                x-d-ux
                                                x-d-aid">
                                <input type="hidden" name="cmd" value="_xclick">
                                <input type="hidden" name="item_number">
                                <input type="hidden" name="business" value="hoolywoodland@gmail.com">
                                <input type="hidden" name="lc" value="US">
                                <input type="hidden" name="item_name" value="ZIP code + 15 miles report">
                                <input type="hidden" name="hosted_button_id" value="3PB5W9H7ZSUHA">
                                @auth
                                <input type="hidden" name="user_id" value="{{ \auth()->user()->id }}">
                                @endauth
                                <input type="hidden" name="amount" value="39.99">
                                <input type="hidden" name="return" value="{{url('/')}}">
                                <input
                                        type="hidden" name="cancel_return"
                                        value="{{url('/')}}">
                                <input type="hidden" name="currency_code" value="USD">
                                <input type="hidden" name="button_subtype" value="products">
                                <input type="hidden" name="cbt"
                                       value="Return to {{env('APP_NAME')}}">
                                <input type="hidden" name="rm" value="0">
                                <input type="hidden" name="no_note" value="0">
                                <input type="hidden" name="shipping" value="0.00">
                                <input type="hidden" name="add" value="1">
                                <input type="hidden" name="bn"
                                       value="PP-ShopCartBF:btn_cart_LG.gif:NonHostedGuest">
                                {{--<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_cart_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">--}}
                                <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif"
                                     width="1" height="1">
                                <div
                                        class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block px_-ff-_Archivo_Black___arial__sans-serif
                                        px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                                    <button
                                            name="submit"
                                            class="x-el x-el-button px_-text-transform-uppercase px_-c-rgb0__0__0 px_-fw-700 px_-pt-10px px_-pb-10px
                                            px_-pl-30px px_-pr-30px px_-fs-12 px_-bc-rgb162__147__138 px_-border-style-none px_-d-inline-block
                                            px_-letter-spacing-1px px_-text-align-center px_-text-decoration-none px_-w-100P
                                            px_-ff-_Montserrat___arial__sans-serif px_-border-radius-1000px px__hover-bc-rgb176__160__150
                                            px__focus-outline-none _smpx_-w-auto _mdpx_-pt-10px _mdpx_-pb-10px _mdpx_-pl-50px _mdpx_-pr-50px
                                            _mdpx_-fs-12 _lgpx_-fs-14 x-d-ux x-d-aid">
                                        <img src="{{ url('/img/design/paypal_ico.png') }}"
                                             class="x-el x-el-img px_-text-transform-none px_-max-width-100P
                                                        px_-ml-0 px_-mr-8px px_-mt-0 px_-mb-0 px_-w-30px px_-h-auto
                                                        px_-ff-_Montserrat___arial__sans-serif px_-fs-12 _mdpx_-fs-14
                                                        _lgpx_-fs-14 x-d-ux">
                                        <span class="x-el x-el-span px_-text-transform-none
                                                px_-ff-_Montserrat___arial__sans-serif px_-fs-12 _mdpx_-fs-14 _lgpx_-fs-14
                                                x-d-ux">
                                                    Enter your Zip Code and Buy Now
                                                </span>
                                    </button>
                                </div>
                            </form>
                            <img src="{{ url('/img/design/cc-badges-ppmcvdam.png') }}"
                                 alt="Pay with PayPal or a debit/credit card"
                                 class="x-el
                                        x-el-img
                                        px_-text-transform-uppercase
                                        px_-max-width-100P
                                        px_-ml-0
                                        px_-mr-0
                                        px_-mt-10px
                                        px_-mb-0
                                        px_-w-150px
                                        px_-h-auto
                                        px_-ff-_Archivo_Black___arial__sans-serif
                                        px_-fs-14
                                        _mdpx_-fs-14
                                        _lgpx_-fs-14
                                        x-d-ux
                                        x-d-aid">
                        </div>
                        <div class="x-el
                                    x-el-p
                                    px_-text-transform-none
                                    px_-overflow-wrap-break-word
                                    px_-word-wrap-break-word
                                    px_-word-break-break-word
                                    px_-c-rgb94__94__94
                                    px_-fs-16
                                    px_-fw-400
                                    px_-lh-1p5
                                    px_-mt-0
                                    px_-mb-0
                                    px_-ff-_Montserrat___arial__sans-serif
                                    _mdpx_-fs-16
                                    _lgpx_-fs-16
                                    x-d-ux
                                    x-d-aid
                                    x-d-route x-rt">
                            <p class="m0">Descriptive report that covers all cars, owners and
                                data for the past calendar year on the requested territory</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>