@extends('layouts.admin')
@section('content')
    <h1>Add report for {{ $user->fullName }}</h1>
    @include('admin.forms.report', [ 'formAction' => url("/admin/users/{$user->id}/add-report"), ])
@endsection