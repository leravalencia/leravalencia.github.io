<footer class="footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © {{ env('APP_NAME') }} 2018 - All Rights Reserved.</small>
        </div>
    </div>
</footer>