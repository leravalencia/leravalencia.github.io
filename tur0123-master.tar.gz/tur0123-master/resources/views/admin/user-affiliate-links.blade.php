@extends('layouts.admin')
@section('content')
    <h1 class="tac">{{$user->email}} affiliate links</h1>
    <form action="{{"/admin/users/{$user->id}/affiliate-links"}}"
          class="form"
          method="post">
        {{csrf_field()}}
        <div class="info">
            Link will be look like <strong>{{url('a', 'example-link-tag')}}</strong>
        </div>
        <div class="form-group">
            <label for="name">Link ending</label>
            <input type="text"
                   class="form-control @if($errors->has('link')) is-invalid @endif"
                   name="link"
                   id="link"
                   placeholder="link-tag"
                   value="{{ old('link', $user->link) }}">
            @if($errors->has('link'))
                <div class="invalid-feedback">{{$errors->first('link')}}</div>
            @endif
        </div>
        <button type="submit" class="btn btn-primary">Create</button>
    </form>
    <div class="mt-5 mb-5">
        <hr>
        @if(empty($user->affiliateLinks))
            <h2>User have no links</h2>
        @else
            <table class="mt-3 table">

                @foreach($user->affiliateLinks as $link)
                    <tr>
                        <td>{{$link->link}}</td>
                        <td>{{$link->views}}</td>
                        <td>{{$link->registers}}</td>
                    </tr>
                @endforeach

            </table>
        @endif
    </div>
@endsection
