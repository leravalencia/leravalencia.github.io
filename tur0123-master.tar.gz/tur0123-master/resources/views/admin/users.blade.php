@extends('layouts.admin')
@section('content')
    <h1 class="align-center">Users</h1>
    <table class="table table-responsive-sm">
        <thead>
        <tr>
            <th>id</th>
            <th>Name</th>
            <th>email</th>
            <th>registration date</th>
            <th></th>
        </tr>
        </thead>
        @foreach($users as $user)
            <tr>
                <td>{{$user->id}}</td>
                <td>{{$user->fullName}}</td>
                <td>{{$user->email}}</td>
                <td>{{$user->created_at->format('m/d/Y H:i:s')}}</td>
                <td>
                    <a href="{{url("/admin/users/{$user->id}/reports")}}" class="btn btn-link">User reports</a>
                    <a href="{{url("/admin/users/{$user->id}/add-report")}}" class="btn btn-outline-primary">
                        ➕ Add report
                    </a>
                    <a href="{{url("/admin/users/{$user->id}")}}" class="btn btn-outline-primary">
                        <i class="fa fa-pencil"></i> Edit
                    </a>
                    @if ($user->partner)
                        <a href="{{url("/admin/users/{$user->id}/affiliate-links")}}" class="btn btn-outline-primary">
                            <i class="fa fa-plus"></i> Add partner link
                        </a>
                    @endif
                </td>
        @endforeach
    </table>
@endsection