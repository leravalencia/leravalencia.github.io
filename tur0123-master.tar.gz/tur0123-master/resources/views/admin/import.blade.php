@extends('layouts.admin')
@section('content')
    <div class="container">
        <h1>Import</h1>
        <form action="{{ url('admin/import') }}" method="post" enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row @if($errors->any())  has-danger @endif">
                <label for="database" class="form-control-label">Database</label>
                <input type="file" required
                       id="database"
                       name="database"
                       class="form-control-file @if($errors->any())form-control-danger @endif">
                @if($errors->any())
                    @foreach($errors->all() as $error)
                        <div class="form-control-feedback db wide">{{$error}}</div>
                    @endforeach
                @endif
            </div>
            <div class="form-group row">
                <input type="submit" value="Upload" class="btn btn-primary">
            </div>
        </form>
    </div>
@endsection
