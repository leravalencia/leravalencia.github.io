@extends('layouts.admin')
@section('content')
    <div class="container">
        <h1>Unprocessed reports</h1>
        @if(!empty($reportOrders))
            <table>
                @foreach($reportOrders as $report)
                    <tr>
                        <td></td>
                    </tr>
                @endforeach
            </table>
        @else
            There are no unprocessed orders
        @endif
    </div>
@endsection
