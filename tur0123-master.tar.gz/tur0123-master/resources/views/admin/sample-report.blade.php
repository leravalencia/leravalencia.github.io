@extends('layouts.admin')
@section('content')
    <h1 class="align-center">Upload sample report</h1>
    <div class="container">
        <form action="{{url('admin/sample-report')}}"
              method="post"
              enctype="multipart/form-data">
            {{ csrf_field() }}
            <div class="form-group row @if($errors->any())  has-danger @endif">
                <label for="sample" class="form-control-label">Sample Report</label>
                @if($errors->any())
                    @foreach($errors->all() as $error)
                        <div class="form-control-feedback db wide text-danger">{{$error}}</div>
                    @endforeach
                @endif
                <input type="file"
                       required
                       id="sample"
                       name="sample"
                       class="form-control-file @if($errors->any())form-control-danger @endif">
            </div>
            <div class="form-group row">
                <button class="btn btn-primary" type="submit">
                    <i class="fa fa-upload"></i>
                    Upload
                </button>
            </div>
        </form>
    </div>
@endsection