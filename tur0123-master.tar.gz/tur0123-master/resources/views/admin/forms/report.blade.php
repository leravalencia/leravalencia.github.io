<form action="{{$formAction}}"
      method="post"
      enctype="multipart/form-data">
    {{csrf_field()}}
    <div class="form-group">
        <label for="report">Report</label>
        <input type="file" class="form-control-file" name="report" required>

        @if ($errors->has('report'))
            <span class="help-block"><strong>{{ $errors->first('report') }}</strong></span>
        @endif
    </div>
    <input type="submit" class="btn btn-primary" value="Submit order">
</form>
