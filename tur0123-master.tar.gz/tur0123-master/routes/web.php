<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/', 'PageController@landing')->name('landing');
Route::get('/a/{link}', 'AffiliateController@setCookieAndRedirect');
Route::post('/feedback', 'FeedbackController@save');
Route::post('/subscribe', 'SubscriptionController@subscribe');
Route::get('/sample/{name}', 'ReportController@sample');

Route::group(['prefix' => 'admin', 'middleware' => ['auth','admin']], function() {
    Route::get('/', 'DashboardController@index')->name('dashboard');
    Route::get('/partners', 'DashboardController@partners')->name('dashboard');
    Route::get('/feedback', 'DashboardController@feedback');
    Route::get('/subscribers', 'DashboardController@subscribers');
    Route::get('/import', 'DashboardController@importPage');
    Route::post('/import', 'DashboardController@importSpreadSheetToDb');
    Route::get('/add-reports', 'DashboardController@addReportsPage');

    Route::get('/sample-report', 'DashboardController@uploadSampleReportPage');
    Route::post('/sample-report', 'DashboardController@uploadSampleReport');

    Route::get('/users', 'DashboardController@usersPage');

    Route::get('/users/{user}', 'DashboardController@userEditForm');
    Route::post('/users/{user}', 'DashboardController@saveUser');

    Route::get('/users/{user}/affiliate-links', 'DashboardController@userAffiliateLinks');
    Route::post('/users/{user}/affiliate-links', 'DashboardController@createUserAffiliateLinks');

    Route::get('/users/{user}/add-report', 'DashboardController@userAddReportPage');
    Route::post('/users/{user}/add-report', 'DashboardController@userAddReport');

    Route::get('/users/{user}/reports', 'DashboardController@userReportsPage');
    Route::get('/users/{user}/reports/{report}', 'DashboardController@reportPage');
    Route::post('/users/{user}/reports/{report}', 'DashboardController@updateReport');
    Route::delete('/users/{user}/reports/{report}', 'DashboardController@deleteReport');

    Route::get('/logs', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index');
});

Route::group(['middleware' => ['auth']], function() {
   Route::get('/profile', 'UserController@profile')->name('profile');
    Route::get('/settings', 'UserController@settings');

    Route::get('/reports/{report}', 'ReportController@getReport');

    /*sidebar tabs*/
    Route::get('/world', 'UserController@worldMap');
    Route::get('/overview', 'UserController@overview');
    Route::get('/pricing', 'UserController@pricing');
    Route::get('/occupancy', 'UserController@occupancy');
    Route::get('/revenue', 'UserController@revenue');
    Route::get('/rental', 'UserController@rental');
    Route::get('/top', 'UserController@top');
    Route::get('/reports', 'UserController@reports');

    Route::get('/testpage', 'UserController@testpage');

    Route::get('/payment/success', 'CheckoutCotnroller@afterPayment');

    Route::group(['middleware' => ['partner']], function () {
       Route::get('/partner', 'PartnerController@index');
    });
});
