import axios from 'axios';
import tingle from 'tingle.js';

const metaToken = document.querySelector('meta[name="csrf-token"]');
if (metaToken) {
  axios.defaults.headers.common['X-CSRF-TOKEN'] = metaToken.getAttribute('content');
}

const modal = new tingle.modal({
  footer: false,
  stickyFooter: false,
  closeMethods: ['overlay', 'button', 'escape'],
  closeLabel: "Close",
});

let showModalButton = document.querySelectorAll('.show-sign-up-modal');
if (showModalButton) {

  let loginModal = document.getElementById('js-login-modal');
  modal.setContent(loginModal.innerHTML);
  loginModal.remove();
  showModalButton.forEach(function (button) {
    button.addEventListener('click', function () {
      modal.open();
    });
  })
}

const subscribeForm = document.getElementById('js-land-subscription-form');
if (subscribeForm) {
  subscribeForm.onsubmit = function (ev) {
    ev.preventDefault();
    const email = document.getElementById('js-land-subscribe_email').value;
    axios.post('/subscribe', {email: email})
      .then(function (res) {
        subscribeForm.style.display = 'none';
        document.getElementById('js-subscribe-res-message').innerText = 'Subscribed successfully';
      })
      .catch(function (res) {
        document.getElementById('js-subscribe-res-message').innerText = 'Some error occurred. Please try again later';
      });
  }
}

const feedbackForm = document.getElementById('js-land-feedback-form');
if (feedbackForm) {
  feedbackForm.onsubmit = function (ev) {
    ev.preventDefault();
    const name = document.getElementById('js-feedback_name').value;
    const email = document.getElementById('js-feedback_email').value;
    const message = document.getElementById('js-feedback_message').value;
    axios.post('/feedback', {
      name: name,
      email: email,
      message: message,
    })
      .then(function (res) {
        feedbackForm.style.display = 'none';
        document.getElementById('js-feedback-res_message').innerText = `Thank you for your message. We'll be in touch soon!`;
      })
      .catch(function (error) {
        if (error.response && error.response.data && error.response.data.errors) {
          let errHtml = '';
          for (let obj in error.response.data.errors) {
            error.response.data.errors[obj].forEach(function (item) {
              errHtml += `${item}<br>`;
            });
          }
          document.getElementById('js-feedback-res_message').innerHTML = errHtml;
        } else {
          document.getElementById('js-feedback-res_message').innerText = 'Some error occurred. Try again later';
        }
      });
  }
}
