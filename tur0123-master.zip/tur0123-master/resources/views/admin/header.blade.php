<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="{{ url('/admin') }}">{{ env('APP_NAME') }}</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
            aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav">
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/import') }}">
                    <i class="fa fa-fw fa-upload"></i>
                    <span class="nav-link-text">Import</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/sample-report') }}">
                    <i class="fa fa-external-link" aria-hidden="true"></i>
                    <span class="nav-link-text">Sample report</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/partners') }}">
                    <i class="fa fa-bullhorn" aria-hidden="true"></i>
                    <span class="nav-link-text">Partner stats</span>
                </a>
            </li>
        {{--    <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/add-reports') }}">
                    ➕ <span class="nav-link-text">Unprocessed reports</span>
                </a>
            </li>--}}
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/users') }}">
                    <i class="fa fa-user"></i>
                    <span class="nav-link-text">Users</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/subscribers') }}">
                    <i class="fa fa-envelope"></i>
                    <span class="nav-link-text">Subscribers</span>
                </a>
            </li>
            <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Import">
                <a class="nav-link" href="{{ url('admin/feedback') }}">
                    <i class="fa fa-comments"></i>
                    <span class="nav-link-text">Feedback</span>
                </a>
            </li>
            <li class="my-2 my-md-0 mr-md-3 nav-item">
                <a href="{{ url('logout') }}" class=" nav-link"><span class="nav-link-text">Log out</span></a>
            </li>
        </ul>
    </div>
</nav>
