@extends('layouts.admin')
@section('content')
    <h1 class="align-center">Subscribers</h1>
    <div class="table-responsive-sm">
        <table class="table ">
            <thead>
            <tr>
                <th>email</th>
                <th>created</th>
            </tr>
            </thead>
            @foreach($subscribers as $subscriber)
                <tr>
                    <td>{{$subscriber->email}}</td>
                    <td>{{$subscriber->created_at}}</td>
                </tr>
            @endforeach
        </table>
    </div>
@endsection