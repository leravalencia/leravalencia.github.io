@extends('layouts.admin')
@section('content')
    <h1 class="center-align">Feedback</h1>
    <div class="table-responsive-sm">
        <table class="table">
            <thead>
            <tr>
                <th>name</th>
                <th>email</th>
                <th>message</th>
                <th>created</th>
            </tr>
            </thead>
            @foreach($feedback as $item)
                <tr>
                    <td>{{$item->name}}</td>
                    <td>{{$item->email}}</td>
                    <td>{{$item->message}}</td>
                    <td>{{$item->created_at}}</td>
                </tr>
            @endforeach
        </table>
    </div>
@endsection