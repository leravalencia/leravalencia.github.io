@extends('layouts.admin')
@section('content')
    <h1 class="align-center">Edit user</h1>
    <form class="form" method="post">
        {{csrf_field()}}
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text"
                   class="form-control @if($errors->has('name')) is-invalid @endif"
                   name="name"
                   id="name"
                   placeholder="Name"
                   value="{{ old('name', $user->name) }}">
            @if($errors->has('name'))
                <div class="invalid-feedback">
                    {{$errors->first('name')}}
                </div>
            @endif
        </div>
        <div class="form-check">
            <input type="checkbox"
                   @if(old('admin') || $user->admin) checked @endif
                   class="form-check-input @if($errors->has('admin')) is-invalid @endif"
                   value="true"
                   id="admin"
                   name="admin">
            <label class="form-check-label" for="admin">Admin</label>
            @if($errors->has('admin'))
                <div class="invalid-feedback">
                    {{$errors->first('admin')}}
                </div>
            @endif
        </div>
        <div class="form-check">
            <input type="checkbox"
                   @if(old('partner') || $user->partner) checked @endif
                   value="true"
                   class="form-check-input @if($errors->has('partner')) is-invalid @endif"
                   id="partner"
                   name="partner">
            <label class="form-check-label" for="partner">Partner</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
@endsection