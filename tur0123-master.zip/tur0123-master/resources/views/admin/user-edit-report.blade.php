@extends('layouts.admin')
@section('content')
    <h1>Edit report of {{ $user->fullName }}</h1>
    @include('admin.forms.report', [ 'formAction' => url("/admin/users/{$user->id}/reports/{$report->id}"), ])
@endsection