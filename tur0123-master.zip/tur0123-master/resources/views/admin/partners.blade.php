@extends('layouts.admin')
@section('content')
    <h1 class="align-center">Partner stats</h1>
    @if($affiliates->isEmpty())
    <h3>There are no registers from partners yet</h3>
    @else
        <h2 class="mt-3">Registers</h2>
        <table class="table">
            <thead>
            <tr>
                <th>User email</th>
                <th>Link</th>
                <th>Register date</th>
                <th>Partner email</th>
            </tr>
            </thead>
            <tbody>

            @foreach($affiliates as $affiliate)
                <tr>
                    <td>{{$affiliate->affiliates->email}}</td>
                    <td>{{$affiliate->link}}</td>
                    <td>{{$affiliate->partner->email}}</td>
                    <td>{{$affiliate->affiliates->created_at->format('d/m/Y')}}</td>
                </tr>
            @endforeach

            </tbody>
        </table>
    @endif

    <div class="mt-5"></div>
    @if($reports->isEmpty())
        <h3>There are no reports bought from invited users</h3>
    @else
        <h2 class="mt-3">Reports</h2>
        <table class="table">
            <thead>
            <tr>
                <th>User email</th>
                <th>Report</th>
                <th>Partner email</th>
                <th>Register date</th>
            </tr>
            </thead>
            <tbody>

            @foreach($reports as $report)
                <tr>
                    <td>{{$report->user->email}}</td>
                    <td>{{$report->file_name}}</td>
                    <td>{{$report->user->affiliatesBy->partner->email}}</td>
                    <td>{{$report->created_at->format('d/m/Y')}}</td>
                </tr>
            @endforeach

            </tbody>
        </table>
    @endif


@endsection