@extends('layouts.admin')
@section('content')
    <h1 class="tac"><span class="text-capitalize">{{$user->fullName}}</span> reports</h1>
    <a href="{{url("/admin/users/{$user->id}/add-report")}}" class="btn btn-outline-primary">➕ Add report</a>
    @if(empty($reports))
        <h2>User have no reports</h2>
    @else
        <table class="mt-3 table">
            @foreach($reports as $report)
                <tr>
                    <td>{{$loop->iteration}}</td>
                    <td><a href="{{url('/reports', $report->id)}}">{{$report->file_name}}</a></td>
                    <td>
                        <a
                            href="{{url("admin/users/{$user->id}/reports/{$report->id}")}}"
                            class="btn btn-outline-secondary">
                            Edit
                        </a>
                    </td>
                    <td>
                        <form action="{{url('admin/users' ,[$user->id, 'reports',$report->id])}}" method="post">
                            <input type="hidden" name="_method" value="delete">
                            {{csrf_field()}}
                            <input type="submit" class="btn btn-outline-danger"
                                   onclick="return confirm('Realy delete')" value="Delete">
                        </form>
                    </td>
                </tr>
            @endforeach
        </table>
    @endif
@endsection
