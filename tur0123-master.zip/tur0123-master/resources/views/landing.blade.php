<html lang="en-US">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>TURO Data, Insights, and Analytics - {{env('APP_NAME')}}</title>
    <meta name="description" content="TURO data and insights to succeed in a car sharing economy">
    <meta name="author" content="{{env('APP_NAME')}}">
    <meta property="og:url" content="{{ url('/') }}">
    <meta property="og:site_name" content="{{env('APP_NAME')}}">
    <meta property="og:title" content="TURO data,  insights and analytics to succeed in a car sharing economy">
    <meta property="og:description" content="TURO data and insights to succeed in a car sharing economy">
    <meta property="og:type" content="website">
    <meta property="og:image" content="{{ asset('/img/bg/01/Turo0123_white.jpg') }}">
    <meta property="og:locale" content="en_US">
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="{{env('APP_NAME')}}">
    <meta name="twitter:description" content="TURO data, insights and analytics to succeed in a car sharing economy">
    <meta name="csrf-token" content="{{csrf_token()}}">
    <meta name="twitter:image"
          content="{{ asset('/img/bg/01/Turo0123_white.jpg') }}">
    <meta name="twitter:image:alt" content="{{env('APP_NAME')}}">
    <link rel="stylesheet" href="{{ mix('/css/pages/landing.css') }}">
</head>
<body class="x beepcode">
<div class="x-el
            x-el-span
            px_-text-transform-uppercase
            px_-ff-_Archivo_Black___arial__sans-serif
            px_-fs-14
            _mdpx_-fs-14
            _lgpx_-fs-14
            x-d-ux">
    @include('landing.header')
    @include('landing.explore')
    @include('landing.order-section')
    @include('landing.about')
    @include('landing.subscribe-section')
    @include('landing.contact-us')
    @include('landing.footer')
    <div id="js-login-modal" class="hidden">
        <h4 class="x px_-fs-36 px_-text-align-center x px_-ff-_Archivo_Black___arial__sans-serif">
            Create your account. It's free!
        </h4>
        <div class="x px_-d-flex x px_-ff-_Montserrat___arial__sans-serif jc_sa mt px_-mt-12px ">
            <div class="w_49%">
                <h5 class="x px_-ff-_Archivo_Black___arial__sans-serif px_-fw-400 px_-text-align-center">
                    Join innovators using {{env('APP_NAME')}}
                </h5>
                <form action="{{url('register')}}" method="POST">
                    {{csrf_field()}}
                    <fieldset class="bw_0">
                        <label for="name">First Name</label>
                        <input class="modal_input"
                               type="text"
                               name="name"
                               id="name">
                    </fieldset>
                    <fieldset class="bw_0">
                        <label for="last_name">Last Name</label>
                        <input class="modal_input"
                               type="text"
                               name="last_name"
                               id="last_name">
                    </fieldset>
                    <fieldset class="bw_0">
                        <label for="email">Email address</label>
                        <input class="modal_input"
                               type="text"
                               name="email"
                               id="email"
                               required>
                    </fieldset>
                    <fieldset class="bw_0">
                        <label for="password">Password</label>
                        <input class="modal_input"
                               type="password"
                               name="password"
                               id="password"
                               required>
                    </fieldset>
                    <fieldset class="bw_0">
                        <label for="password_confirmation">Confirm Password</label>
                        <input class="modal_input"
                               type="password"
                               name="password_confirmation"
                               id="password_confirmation"
                               required>
                    </fieldset>
                    <input type="submit" value="Sign up" class="modal-btn_submit">
                </form>
            </div>
            <div class="w_49%">
                <h5 class="x px_-text-align-center x px_-ff-_Archivo_Black___arial__sans-serif px_-fw-400">
                    Why sign up?
                </h5>
                <ul class="modal-ul">
                    <li>Access sample information</li>
                    <li>Order individual customized report</li>
                    <li>Discover investment opportunities</li>
                </ul>
            </div>
        </div>
        <div class="x px_-ff-_Archivo_Black___arial__sans-serif px_-text-align-center">
            Already have an account? <a href="{{url('login')}}">Log in</a></div>
    </div>
</div>
<script src="{{ mix('js/landing.js') }}"></script>
<script type="text/javascript" src="//script.crazyegg.com/pages/scripts/0072/9058.js" async="async"></script>
</body>
</html>