<section class="x-el
                x-el-section
                px_-text-transform-uppercase
                px_-bc-rgb22__22__22
                px_-pt-60px
                px_-pb-60px
                px_-ff-_Archivo_Black___arial__sans-serif
                px_-fs-14
                _mdpx_-fs-14
                _lgpx_-fs-14
                x-d-ux">
    <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
        <div class="x-el x-el-div px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase
                         px_-d-flex px_-box-sizing-border-box
                            px_-flex-direction-row px_-flex-wrap-wrap
                                 px_-m-0 px_-align-items-center px_-text-align-centerpx_-ff-_Archivo_Black___arial__sans-serif
                                  px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1
                                    px_-flex-shrink-1 px_-flex-basis-100P px_-p-0 px_-max-width-100P
                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-flex-basis-0P
                                    _mdpx_-max-width-none _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h5 class="x-el x-el-h5 px_-text-transform-none px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word px_-word-break-break-word px_-fs-16 px_-c-rgb247__247__247
                                        px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                        px_-ff-_Montserrat___arial__sans-serif _mdpx_-text-align-left _mdpx_-fs-16 _lgpx_-fs-16
                                        x-d-ux x-d-aid x-d-route x-rt">
                        Copyright &copy; {{date('Y')}} {{env('APP_NAME')}} - All Rights Reserved.
                    </h5>
                </div>
                <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1
                                    px_-flex-shrink-1 px_-flex-basis-100P px_-p-0 px_-max-width-100P
                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-flex-basis-0P
                                    _mdpx_-max-width-none _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                </div>
            </div>
        </div>
    </div>
</section>