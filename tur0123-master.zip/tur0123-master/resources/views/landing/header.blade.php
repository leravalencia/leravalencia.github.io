<div class="x-el x-el-div px_-text-transform-uppercase px_-z-index-1001
                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                     _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
    <section class="x-el x-el-section px_-text-transform-uppercase px_-bc-rgb22__22__22 px_-pt-0
                        px_-pb-0 px_-overflow-hidden px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-none
                            px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-d-block _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
        </div>
        <div class="x-el x-el-div px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <span class="x-el x-el-span px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                </span>
        </div>
        <div class="x-el x-el-div
                            px_-text-transform-uppercase
                            px_-position-absolute
                            px_-z-index-2
                            px_-w-100P
                            px_-bc-
                            px_-ff-_Archivo_Black___arial__sans-serif
                            px_-fs-14
                            _mdpx_-fs-14
                            _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase
                                 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase
                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <nav class="x-el x-el-nav px_-text-transform-uppercase px_-ml-auto
                                         px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P px_-pt-20px px_-pb-20px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex
                                     px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-nowrap px_-m-0_-10px_0 px_-align-items-center px_-text-align-center px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-d-none _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <div class="df
                            al-it-c
                                        jc_sa
                                        x-el x-el-div px_-text-transform-uppercase
                                        px_-box-sizing-border-box
                                         px_-flex-grow-1 px_-flex-shrink-1
                                         px_-flex-basis-auto px_-p-0_10px_0
                                         px_-ff-_Archivo_Black___arial__sans-serif
                                         px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                <div class="df
                                jc_sa
                                            x-el x-el-div px_-text-transform-uppercase
                                            px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                             _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid
                                             x-d-route">
                                    <a href="{{ url('/') }}"
                                       title="{{env('APP_NAME')}}"
                                       class="
                                                   mr3rem
                                                   x-el
                                                    x-el-a
                                                    px_-text-transform-none
                                                    px_-overflow-wrap-break-word
                                                    px_-fs-16
                                                    px_-fw-400
                                                   px_-c-rgb162__147__138
                                                   px_-text-decoration-none
                                                   px_-d-inline
                                                   px_-cursor-pointer
                                                    px_-ff-_Montserrat___arial__sans-serif px__hover-c-rgb163__148__139 _mdpx_-fs-16 _lgpx_-fs-16
                                                     x-d-ux x-d-page">
                                        <h3 class="df
                                        al-it-c
                                        x-el x-el-h3 px_-text-transform-uppercase px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word px_-word-break-break-word px_-fs-18 px_-c-rgb247__247__247
                                                    px_-fw-400 px_-lh-1p2 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                                    px_-ff-_Archivo_Black___arial__sans-serif _mdpx_-fs-19 _lgpx_-fs-20 x-d-ux">
                                            <img src="{{asset('img/design/BeepCode_logo_only_100.png')}}"
                                                 alt="{{env('APP_NAME')}} logo"
                                                 class="w40px mr1rem"
                                            >
                                            {{env('APP_NAME')}}
                                        </h3>
                                    </a>
                                    <a href="{{ url('/login') }}"
                                       title="{{env('APP_NAME')}}"
                                       class="al-se-c
                                       x-el x-el-a px_-text-transform-none px_-overflow-wrap-break-word px_-fs-16 px_-fw-400
                                                   px_-c-rgb162__147__138 px_-text-decoration-none px_-d-inline px_-cursor-pointer
                                                    px_-ff-_Montserrat___arial__sans-serif px__hover-c-rgb163__148__139 _mdpx_-fs-16 _lgpx_-fs-16
                                                     x-d-ux x-d-page">
                                        <h3 class="x-el x-el-h3 px_-text-transform-uppercase px_-overflow-wrap-break-word
                                                    px_-word-wrap-break-word px_-word-break-break-word px_-fs-18 px_-c-rgb247__247__247
                                                    px_-fw-400 px_-lh-1p2 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                                    px_-ff-_Archivo_Black___arial__sans-serif _mdpx_-fs-19 _lgpx_-fs-20 x-d-ux">
                                            Log in
                                        </h3>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="x-el x-el-div
                                    px_-text-transform-uppercase
                                    px_-d-none
                                    px_-box-sizing-border-box
                                    px_-flex-direction-row
                                    px_-flex-wrap-wrap
                                    px_-m-0_-10px_0
                                    px_-align-items-center
                                    px_-ff-_Archivo_Black___arial__sans-serif
                                    px_-fs-14
                                    _smpx_-m-0_-20px_0
                                    _mdpx_-d-flex
                                    _mdpx_-fs-14
                                    _lgpx_-fs-14
                                     x-d-ux">
                            <div class="
                                        df jc_c
                                        x-el
                                        x-el-div
                                        px_-text-transform-uppercase
                                        px_-box-sizing-border-box
                                        px_-flex-grow-1
                                        px_-flex-shrink-1
                                        px_-flex-basis-100P
                                        px_-p-0_10px_0
                                        px_-max-width-100P
                                        px_-text-align-center
                                        px_-ff-_Archivo_Black___arial__sans-serif
                                        px_-fs-14 _smpx_-p-0_20px_0
                                        _mdpx_-fs-14
                                        _lgpx_-fs-14 x-d-ux">
                                <div class="
                                            df
                                            x-el
                                            x-el-div
                                            px_-text-transform-uppercase
                                            px_-ff-_Archivo_Black___arial__sans-serif
                                            px_-fs-14
                                            _mdpx_-fs-14
                                            _lgpx_-fs-14 x-d-ux x-d-aid x-d-route">
                                    <a href="{{ url('/') }}"
                                       title="{{env('APP_NAME')}}"
                                       class="x-el x-el-a px_-text-transform-none px_-overflow-wrap-break-word
                                                        px_-fs-16 px_-fw-400 px_-c-rgb162__147__138 px_-text-decoration-none
                                                         px_-d-inline px_-cursor-pointer px_-ff-_Montserrat___arial__sans-serif
                                                         px__hover-c-rgb163__148__139 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-page">
                                        <h3 class="mr10rem
                                        df
                                        al-it-c
                                        x-el
                                        x-el-h3
                                        px_-text-transform-uppercase
                                        px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word
                                        px_-word-break-break-word
                                        px_-fs-18
                                        px_-c-rgb247__247__247
                                        px_-fw-400
                                        px_-lh-1p2
                                        px_-ml-0
                                        px_-mt-0
                                        px_-mb-0
                                        px_-ff-_Archivo_Black___arial__sans-serif
                                        _mdpx_-fs-19
                                        _lgpx_-fs-20
                                        x-d-ux">
                                            <img src="{{asset('img/design/BeepCode_logo_only_100.png')}}"
                                                 alt="{{env('APP_NAME')}} logo"
                                                 class="w40px mr1rem"
                                            >
                                            <span>{{env('APP_NAME')}}</span>
                                        </h3>
                                    </a>
                                    <a href="{{ url('/login') }}"
                                       title="{{env('APP_NAME')}}"
                                       class="al-se-c
                                            x-el x-el-a px_-text-transform-none px_-overflow-wrap-break-word
                                                        px_-fs-16 px_-fw-400 px_-c-rgb162__147__138 px_-text-decoration-none
                                                         px_-d-inline px_-cursor-pointer px_-ff-_Montserrat___arial__sans-serif
                                                         px__hover-c-rgb163__148__139 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-page">
                                        <h3 class="x-el x-el-h3
                                                    px_-text-transform-uppercase
                                                    px_-overflow-wrap-break-word
                                                    px_-word-wrap-break-word
                                                    px_-word-break-break-word
                                                    px_-fs-18 px_-c-rgb247__247__247
                                                    px_-fw-400 px_-lh-1p2 px_-ml-0
                                                    px_-mr-0 px_-mt-0 px_-mb-0
                                                    px_-ff-_Archivo_Black___arial__sans-serif
                                                    _mdpx_-fs-19
                                                    _lgpx_-fs-20
                                                    x-d-ux">
                                            Log in
                                        </h3>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto px_-mr-auto px_-pl-20px
                                px_-pr-20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
                        <hr class="x-el x-el-hr px_-text-transform-uppercase
                                    px_-border-color-rgba255__255__255__0p3 px_-border-bottom-width-1px
                                    px_-border-style-solid px_-mt-0 px_-mb-0 px_-w-100P
                                     px_-m-0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                      _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    </div>
                </div>
            </div>
        </div>
        <div class="x-el x-el-div px_-text-transform-uppercase
                    px_-ff-_Archivo_Black___arial__sans-serif
                    px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
            <span class="x-el x-el-span px_-text-transform-uppercase
             px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
              _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux"></span>
            <div class="x-el x-el-div px_-text-transform-uppercase px_-position-relative
                         px_-overflow-visible px_-m-0 px_-w-100P px_-h-auto px_-ff-_Archivo_Black___arial__sans-serif
                         px_-fs-14 _mdpx_-min-height-85vh _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px_-h-100P px_-w-100P
                            px_-position-absolute px_-top-0 px_-left-0 px_-right-0 px_-bottom-0 px_-d-flex
                             px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div class="x-el x-el-div
                                px_-text-transform-uppercase
                                px_-background-size-cover
                                px_-background-position-center
                                px_-bi-url___img1pwsimgpcom_isteam_ip_26ae0427-42e7-4521-ab9e-67cbe21e0480_bfc73aa2-b5dc-4d43-9706
                                -f4252ec496a2pjpg___rs_w_50_h_50_cg_true_m_cr_w_50_h_50_a_cc_ px_-w-100P
                                px_-min-height-300px px_-ff-_Archivo_Black___arial__sans-serif
                                px_-fs-14 _mdpx_-min-height-50vh _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid"
                         style="background-image: url('{{ asset('/img/bg/01/Turo0123_white.jpg') }}');"></div>
                </div>
                <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex
                            px_-align-items-stretch px_-position-relative px_-ff-_Archivo_Black___arial__sans-serif
                            px_-fs-14 _mdpx_-flex-grow-1 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex
                                 px_-flex-direction-column px_-min-height-300px px_-w-100P
                                  px_-bc-rgba22__22__22__0p3 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                  _mdpx_-min-height-85vh _mdpx_-flex-grow-1 _mdpx_-fs-14 _lgpx_-fs-14
                                  x-d-ux x-d-herobg-test">
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-mt-60px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-d-flex _mdpx_-flex-direction-column _mdpx_-flex-grow-1 _mdpx_-flex-shrink-0 _mdpx_-flex-basis-auto _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <div class="x-el x-el-div px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif
                                        px_-fs-14 _mdpx_-d-flex _mdpx_-flex-direction-column _mdpx_-flex-grow-1 _mdpx_-flex-shrink-0
                                        _mdpx_-flex-basis-auto _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                                    <span class="x-el x-el-span px_-text-transform-uppercase
                                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14
                                                    _lgpx_-fs-14 x-d-ux">
                                                    </span>
                                <div class="x-el x-el-div px_-text-transform-uppercase px_-w-100P px_-pt-30px
                                            px_-pb-30px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-pt-60px
                                            _mdpx_-pb-60px _mdpx_-d-flex _mdpx_-flex-direction-column _mdpx_-flex-grow-1
                                            _mdpx_-flex-shrink-0 _mdpx_-flex-basis-auto _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                    <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto
                                                px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P px_-position-relative
                                                 px_-text-align-center px_-w-100P px_-ff-_Archivo_Black___arial__sans-serif
                                                  px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-d-flex
                                                  _mdpx_-flex-direction-column _mdpx_-flex-grow-1 _mdpx_-flex-shrink-0
                                                  _mdpx_-flex-basis-auto _mdpx_-align-items-center
                                                  _mdpx_-justify-content-space-around _mdpx_-fs-14
                                                  _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
                                        <div class="x-el x-el-div px_-text-transform-uppercase
                                                    px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-pb-12px
                                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-pb-30px
                                                    _mdpx_-max-width-66P _mdpx_-ml-40px _mdpx_-mr-40px
                                                    _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                            <h1 class="x-el x-el-h1 px_-text-transform-uppercase
                                                         px_-overflow-wrap-break-word px_-word-wrap-normal
                                                          px_-word-break-keep-all px_-fs-36 px_-c-rgb255__255__255 px_-fw-400
                                                          px_-lh-1p2 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                                          px_-ff-_Archivo_Black___arial__sans-serif _mdpx_-fs-49
                                                          _lgpx_-fs-54 x-d-ux x-d-aid x-d-route">
                                                TURO data, insights and analytics to succeed in a car
                                                sharing economy</h1>
                                        </div>
                                        <div
                                                type="tel"
                                                class="x-el x-el-div px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb255__255__255 px_-fs-20 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px_-pt-12px _mdpx_-ml-40px _mdpx_-mr-40px _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route">
                                            <a href="mailto:{{env('CONTACT_EMAIL')}}"
                                               class="tdn x-el x-el-div px_-text-transform-none
                                                        px_-overflow-wrap-break-word px_-word-wrap-break-word
                                                        px_-word-break-break-word px_-c-rgb255__255__255 px_-fs-20 px_-fw-400
                                                         px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                                                         px_-pt-12px _mdpx_-ml-40px _mdpx_-mr-40px _mdpx_-fs-22 _lgpx_-fs-22
                                                         x-d-ux x-d-route">{{env('CONTACT_EMAIL')}}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
