<section class="x-el
                x-el-section
                px_-text-transform-uppercase
                px_-bc-rgb246__246__246
                px_-pt-80px
                px_-pb-80px
                px_-ff-_Archivo_Black___arial__sans-serif
                px_-fs-14
                _mdpx_-fs-14
                _lgpx_-fs-14
                x-d-ux">
    <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto
                px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P
                px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px
                _lgpx_-fs-14 x-d-ux">
        <h2 class="x-el x-el-h2 px_-text-transform-uppercase
                    px_-overflow-wrap-break-word px_-word-wrap-break-word
                    px_-word-break-break-word px_-fs-23 px_-c-rgb121__109__102
                    px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-40px
                    px_-ff-_Archivo_Black___arial__sans-serif
                    px_-overflow-hidden px_-text-align-center
                    _mdpx_-text-align-center _mdpx_-fs-26
                    _lgpx_-fs-28 x-d-ux x-d-aid x-d-route">
                        <span class="x-el x-el-span px_-text-transform-uppercase
                         px_-d-inline-block px_-position-relative px_-c-inherit
                         px_-max-width-80P px_-ff-_Archivo_Black___arial__sans-serif
                         px_-fs-23 px__before-right-100P px__before-mr-20px
                         px__before-content-__ px__before-h-1px px__before-mt--1px
                         px__before-b-currentColor px__before-position-absolute
                         px__before-top-p75em px__before-w-100vw px__before-d-block
                         px__after-left-100P px__after-ml-20px px__after-content-__ px__after-h-1px
                         px__after-mt--1px px__after-b-currentColor px__after-position-absolute
                         px__after-top-p75em px__after-w-100vw px__after-d-block _mdpx_-fs-26
                         _lgpx_-fs-28 x-d-ux">
                            About Us
                        </span>
        </h2>
        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box
                     px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_-20px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_-40px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div
                            class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-align-self-flex-start px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-mb-20px px_-text-align-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-max-height-269 _mdpx_-mb-0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                            <div>
                                <img
                                        src="{{ url('/img/design/methodologies.jpg') }}"
                                        class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump x-d-subject">
                                <div>
                                    <div>
                                                    <span class="x-el x-el-span px_-text-transform-uppercase
                                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                                    _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-d-flex px_-justify-content-flex-start px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div
                                class="x-el x-el-div x-el px_-text-transform-uppercase px_-d-flex px_-flex-direction-column px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-justify-content-center px_-text-align-left px_-w-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <h4
                                    class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb21__21__21 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                                            <span
                                                    class="x-el x-el-div x-el px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route">
                                                <span
                                                        class="x-el x-el-div px_-text-transform-none px_-d-inline-block px_-cursor-auto px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-section-jump x-d-subject">
                                                    Methodology
                                                </span>
                                                    <span>
                                                        <span class="x-el x-el-span px_-text-transform-none
                                                        px_-ff-_Montserrat___arial__sans-serif px_-fs-20
                                                        _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux">
                                                        </span>
                                                    </span>
                                            </span>
                            </h4>
                            <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word
                                        px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0
                                        px_-ff-_Montserrat___arial__sans-serif px__CA_p_CA_ol-list-style-position-inside px__CA_p_CA_ol-text-align-left
                                         px__CA_p_CA_ol-d-inline-block px__CA_p_CA_ol-p-0 px__CA_p_CA_ul-list-style-position-inside
                                         px__CA_p_CA_ul-text-align-left
                                        px__CA_p_CA_ul-d-inline-block px__CA_p_CA_ul-p-0 px__CA_ul-list-style-position-inside px__CA_ul-text-align-left
                                         px__CA_ul-d-inline-block px__CA_ul-p-0 px__CA_ol-list-style-position-inside px__CA_ol-text-align-left
                                         px__CA_ol-d-inline-block px__CA_ol-p-0 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                                <p style="margin:0px;">{{env('APP_NAME')}} analytics and reports are based on Turo
                                    data gathered from information publicly available on the Turo website.
                                    Our database currently tracks the performance of about 200,000 Turo
                                    listings around the globe each day, generating our custom raw data
                                    reports. {{env('APP_NAME')}} is the only trusted source for short-term car rental
                                    data that provides occupancy rates and revenue data for the past 12
                                    months.</p>
                            </div>
                            <div class="x-el x-el-div px_-text-transform-uppercase
                                         px_-mt-20px px_-w-100P
                                         px_-ff-_Archivo_Black___arial__sans-serif
                                         px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14
                                         x-d-ux">
                                <div>
                                        <span class="x-el x-el-span px_-text-transform-uppercase
                                        px_-ff-_Archivo_Black___arial__sans-serif
                                        px_-fs-14 _mdpx_-fs-14
                                        _lgpx_-fs-14 x-d-ux">
                                            <a target="_blank"
                                               href="{{$reportLink}}"
                                               class="x-el
                                                        x-el-a
                                                        px_-text-transform-uppercase
                                                        px_-c-rgb0__0__0
                                                        px_-fw-700
                                                        px_-pt-10px
                                                        px_-pb-10px
                                                        px_-pl-30px
                                                        px_-pr-30px
                                                        px_-fs-12
                                                        px_-bc-rgb162__147__138
                                                        px_-border-style-none
                                                        px_-d-inline-block
                                                        px_-letter-spacing-1px
                                                        px_-text-align-center
                                                        px_-text-decoration-none
                                                        px_-w-100P
                                                        px_-ff-_Montserrat___arial__sans-serif
                                                        px_-border-radius-1000px
                                                        px__hover-bc-rgb176__160__150
                                                        px__focus-outline-none
                                                        _smpx_-w-auto
                                                        _mdpx_-pt-10px
                                                        _mdpx_-pb-10px
                                                        _mdpx_-pl-50px
                                                        _mdpx_-pr-50px
                                                        _mdpx_-fs-12
                                                        _lgpx_-fs-14
                                                        x-d-ux
                                                        x-d-aid
                                                        x-d-section-jump">
                                                Check Our Sample Report
                                            </a>
                                        </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="x-el x-el-div px_-text-transform-uppercase
                         px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1
                          px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P
                          px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                           _smpx_-p-0_20px_40px _mdpx_-fs-14 _lgpx_-fs-14
                           x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex
                                    px_-box-sizing-border-box px_-flex-direction-row-reverse
                                    px_-flex-wrap-wrap px_-m-0_-10px_0 px_-justify-content-center
                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                     _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div class="x-el x-el-div px_-text-transform-uppercase
                                px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1
                                px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P
                                px_-align-self-flex-start px_-justify-content-center
                                px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0
                                _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14
                                _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div px_-text-transform-uppercase px_-mb-20px
                                    px_-text-align-center px_-ff-_Archivo_Black___arial__sans-serif
                                    px_-fs-14 _mdpx_-max-height-269 _mdpx_-mb-0 _mdpx_-fs-14
                                    _lgpx_-fs-14 x-d-ux x-d-route">
                            <div>
                                <img src="{{ url('/img/design/network_map.jpg') }}"
                                     class="x-el x-el-img px_-text-transform-uppercase
                                                    px_-max-width-100P px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                                    px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                                    _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page
                                                    x-d-section-jump x-d-subject">
                                <div>
                                                    <span class="x-el x-el-span px_-text-transform-uppercase
                                                     px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                                      _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div
                            class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-d-flex px_-justify-content-flex-start px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div x-el px_-text-transform-uppercase px_-d-flex px_-flex-direction-column px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-justify-content-center px_-text-align-left px_-w-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <h4
                                    class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb21__21__21 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                                <div class="x-el x-el-div x-el px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route">
                                    <div
                                            class="x-el x-el-div px_-text-transform-none px_-d-inline-block px_-cursor-auto px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-section-jump x-d-subject">
                                        How does {{env('APP_NAME')}} determine the exact location of cars?
                                    </div>
                                    <div>
                                        <div
                                                id="bootstrap-3397-t">
                                                        <span
                                                                class="x-el x-el-span px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux">

                                                        </span>
                                        </div>
                                    </div>
                                </div>
                            </h4>
                            <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px__CA_p_CA_ol-list-style-position-inside px__CA_p_CA_ol-text-align-left px__CA_p_CA_ol-d-inline-block px__CA_p_CA_ol-p-0 px__CA_p_CA_ul-list-style-position-inside px__CA_p_CA_ul-text-align-left px__CA_p_CA_ul-d-inline-block px__CA_p_CA_ul-p-0 px__CA_ul-list-style-position-inside px__CA_ul-text-align-left px__CA_ul-d-inline-block px__CA_ul-p-0 px__CA_ol-list-style-position-inside px__CA_ol-text-align-left px__CA_ol-d-inline-block px__CA_ol-p-0 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                                <p
                                        style="margin:0px;">&nbsp;</p>
                                <p style="margin:0px;">We create a much more exact property location than is
                                    shown on the Turo website by taking the center point of the average
                                    displayed latitude and longitude coordinates.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div
                    class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <div
                            class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-align-self-flex-start px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div
                                class="x-el x-el-div px_-text-transform-uppercase px_-mb-20px px_-text-align-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-max-height-269 _mdpx_-mb-0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                            <div>
                                <img
                                        src="{{ url('/img/design/guarantee.png') }}"
                                        class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump x-d-subject">
                                <div>
                                                    <span
                                                            class="x-el x-el-span px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">

                                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-d-flex px_-justify-content-flex-start px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-flex-basis-50P _mdpx_-max-width-50P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                        <div class="x-el x-el-div x-el px_-text-transform-uppercase px_-d-flex px_-flex-direction-column px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-justify-content-center px_-text-align-left px_-w-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                            <h4
                                    class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb21__21__21 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                                <div
                                        class="x-el x-el-div x-el px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-route">
                                    <div
                                            class="x-el x-el-div px_-text-transform-none
                                                        px_-d-inline-block px_-cursor-auto px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-section-jump x-d-subject">
                                        100% Satisfaction Guaranteed
                                    </div>
                                    <div>
                                                        <span

                                                                class="x-el x-el-span px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-20 _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux">

                                                        </span>
                                    </div>
                                </div>
                            </h4>
                            <div
                                    class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px__CA_p_CA_ol-list-style-position-inside px__CA_p_CA_ol-text-align-left
                                                px__CA_p_CA_ol-d-inline-block px__CA_p_CA_ol-p-0 px__CA_p_CA_ul-list-style-position-inside px__CA_p_CA_ul-text-align-left px__CA_p_CA_ul-d-inline-block px__CA_p_CA_ul-p-0 px__CA_ul-list-style-position-inside px__CA_ul-text-align-left px__CA_ul-d-inline-block px__CA_ul-p-0 px__CA_ol-list-style-position-inside px__CA_ol-text-align-left px__CA_ol-d-inline-block px__CA_ol-p-0 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                                <p
                                        style="margin:0px;">While getting a report from us, we want you to
                                    be completely happy with the experience. If you have questions about us,
                                    our products, get in touch! We hope will help you to earn more and you
                                    will come back to us again!&nbsp;</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
