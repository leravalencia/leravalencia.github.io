<div id="110e6179-a756-49df-ad45-16542eb5c072" class="widget widget-rss widget-rss-rss-3">
    <section
            class="x-el x-el-section px_-text-transform-uppercase px_-bc-rgb255__255__255 px_-pt-80px px_-pb-80px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
        <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto px_-mr-auto px_-pl-20px px_-pr-20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
            <h2
                    class="x-el x-el-h2 px_-text-transform-uppercase px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-23 px_-c-rgb129__117__109 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-40px px_-ff-_Archivo_Black___arial__sans-serif px_-overflow-hidden px_-text-align-center _mdpx_-text-align-center _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux x-d-aid x-d-route">
                        <span
                                class="x-el x-el-span px_-text-transform-uppercase px_-d-inline-block px_-position-relative px_-c-inherit px_-max-width-80P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-23 px__before-right-100P px__before-mr-20px px__before-content-__ px__before-h-1px px__before-mt--1px px__before-b-currentColor px__before-position-absolute px__before-top-p75em px__before-w-100vw px__before-d-block px__after-left-100P px__after-ml-20px px__after-content-__ px__after-h-1px px__after-mt--1px px__after-b-currentColor px__after-position-absolute px__after-top-p75em px__after-w-100vw px__after-d-block _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux"> Blog</span>
            </h2>
            <div>
                <div
                        id="110e6179-a756-49df-ad45-16542eb5c072-bootstrap-container">
                            <span
                                    class="x-el x-el-span px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                <div>
                                    <div
                                            class="x-el x-el-div px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
                                        <div
                                                class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0 px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_0 _mdpx_-ml-16p666666666666664P _mdpx_-flex-basis-66p66666666666666P _mdpx_-max-width-66p66666666666666P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                            <a

                                                    class="x-el x-el-a px_-text-transform-none px_-overflow-wrap-break-word px_-fs-16 px_-fw-400 px_-c-rgb129__117__109 px_-text-decoration-none px_-d-inline px_-cursor-pointer px_-ff-_Montserrat___arial__sans-serif px__hover-c-rgb115__104__98 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                                <div
                                                        class="x-el x-el-div px_-text-transform-none px_-d-flex px_-flex-direction-column px_-pb-40px px_-mb-0 px_-border-bottom-width-0 px_-border-bottom-style-solid px_-border-color-rgb226__226__226 px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _smpx_-flex-direction-row _smpx_-align-items-center _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid">
                                                    <div
                                                            class="x-el x-el-div px_-text-transform-none px_-d-flex px_-h-200px px_-flex-shrink-0 px_-mb-30px px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _smpx_-w-200px _smpx_-mb-0 _smpx_-mr-30px _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                                        <div
                                                                id="guacBg1"
                                                                class="x-el x-el-div px_-text-transform-none px_-background-size-cover px_-background-position-center px_-bi-url___img1pwsimgpcom_isteam_ip_26ae0427-42e7-4521-ab9e-67cbe21e0480_db4820c4-e94f-4469-aa8e-120905817265pjpg___rs_w_200_ px_-w-100P px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _smpx_-background-size-contain _smpx_-background-repeat-no-repeat _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux"
                                                        >
                                                        </div>
                                                    </div>
                                                    <div class="x-el x-el-div px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _smpx_-d-flex _smpx_-min-width-1px _smpx_-flex-direction-column _smpx_-justify-content-space-between _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                                        <p

                                                                class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px_-pb-12px _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid">January 21, 2018</p>
                                                        <div
                                                                class="x-el x-el-div px_-text-transform-none px_-ff-_Montserrat___arial__sans-serif px_-fs-16 _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux">
                                                            <h4

                                                                    class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb27__27__27 px_-fw-400 px_-lh-1p125 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px_-pb-12px _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux">TURO launch in Germany. More data coming</h4>
                                                            <p
                                                                    class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif px_-pb-12px _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid">Turo launched their service in Germany on January 19th! Over the past four months alone, there were over a million new people join the Turo community and Turo Canada has grown rapidly — faster than the US — reached 275,000 community members in less than two years. </p>
                                                        </div>
                                                        <span class="x-el x-el-span px_-text-transform-uppercase px_-overflow-wrap-break-word px_-fs-12 px_-fw-400 px_-c-rgb129__117__109 px_-text-decoration-none px_-d-inline px_-cursor-pointer px_-ff-_Montserrat___arial__sans-serif px__hover-c-rgb115__104__98 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">{{--Continue Reading--}}</span>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </span>
                </div>
            </div>
        </div>
    </section>
</div>