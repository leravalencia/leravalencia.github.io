<section class="x-el x-el-section px_-text-transform-uppercase
         px_-bc-rgb255__255__255 px_-pt-80px px_-pb-80px
         px_-ff-_Archivo_Black___arial__sans-serif
         px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
    <h4 class="x-el x-el-h3 px_-text-transform-uppercase px_-overflow-wrap-break-word px_-word-wrap-break-word
                px_-word-break-break-word px_-fs-23 px_-c-rgb21__21__21 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0
                px_-mb-12px px_-ff-_Archivo_Black___arial__sans-serif px_-text-align-center _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux
                x-d-aid x-d-route">
        Want to explore and see more detailed stats?
    </h4>
    <button class="cta-modal-button show-sign-up-modal">
        Join now
    </button>
    <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto
            px_-mr-auto px_-pl-20px px_-pr-20px
            px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif
            px_-fs-14 _smpx_-w-728px _mdpx_-w-984px
            _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
        <h2 class="x-el x-el-h2 px_-text-transform-uppercase px_-overflow-wrap-break-word
                            px_-word-wrap-break-word px_-word-break-break-word px_-fs-23
                            px_-c-rgb129__117__109 px_-fw-400
                            px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-40px
                            px_-ff-_Archivo_Black___arial__sans-serif
                            px_-overflow-hidden px_-text-align-center
                            _mdpx_-text-align-center _mdpx_-fs-26 _lgpx_-fs-28
                             x-d-ux x-d-aid x-d-route">
                        <span
                                class="x-el x-el-span px_-text-transform-uppercase px_-d-inline-block px_-position-relative
                                 px_-c-inherit px_-max-width-80P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-23
                                 px__before-right-100P px__before-mr-20px px__before-content-__ px__before-h-1px
                                 px__before-mt--1px px__before-b-currentColor px__before-position-absolute px__before-top-p75em
                                 px__before-w-100vw px__before-d-block px__after-left-100P px__after-ml-20px
                                 px__after-content-__ px__after-h-1px px__after-mt--1px px__after-b-currentColor
                                 px__after-position-absolute px__after-top-p75em px__after-w-100vw px__after-d-block
                                 _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux">
                            Our data relevant for every owner
                        </span>
        </h2>
        <div class="x-el x-el-div x-el px_-text-transform-uppercase px_-text-align-center px_-justify-content-center px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux px_-text-transform-uppercase px_-d-flex px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_-20px px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_-40px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase
                    px_-box-sizing-border-box
                    px_-flex-grow-1 px_-flex-shrink-1
                    px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P
                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px
                    _smpx_-flex-basis-50P _smpx_-max-width-50P
                    _mdpx_-flex-basis-33p33333333333333P
                    _mdpx_-max-width-33p33333333333333P
                    _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4 class="x-el x-el-h4 px_-text-transform-none
                                        px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word
                                        px_-word-break-break-word
                                        px_-fs-20
                                        px_-c-rgb27__27__27
                                        px_-fw-400 px_-lh-1p25
                                        px_-ml-0
                                        px_-mr-0
                                        px_-mt-0
                                        px_-mb-0
                                        px_-ff-_Montserrat___arial__sans-serif
                                        _mdpx_-fs-22
                                        _lgpx_-fs-22
                                        x-d-ux
                                        x-d-aid
                                        x-d-route">
                        Occupancy Rates
                    </h4>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block
                                        px_-max-width-360 px_-h-auto px_-cursor-auto
                                        px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14
                                        x-d-ux x-d-route">
                        <img src="{{ url('/img/design/graph.jpg') }}"
                             class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0
                                         px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Archivo_Black___arial__sans-serif
                                         px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16
                                px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                                _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                        <p style="margin:0px;">Our technology allows us to evaluate occupancy for all
                            cars at the market.&nbsp;</p>
                        <p>
                            <br>
                        </p>
                    </div>
                </div>
            </div>
            <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1
                    px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P
                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px _smpx_-flex-basis-50P
                    _smpx_-max-width-50P _mdpx_-flex-basis-33p33333333333333P _mdpx_-max-width-33p33333333333333P
                    _mdpx_-fs-14
                    _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4 class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word
                                 px_-word-wrap-break-word px_-word-break-break-word px_-fs-20
                                 px_-c-rgb27__27__27 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0
                                 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux
                                 x-d-aid x-d-route">
                        Historical Listing Data</h4>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block
                                px_-max-width-360 px_-h-auto px_-cursor-auto
                                 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux
                                 x-d-route">
                        <img src="{{ url('/img/design/charts.jpg') }}"
                             class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0
                                         px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Archivo_Black___arial__sans-serif
                                         px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page
                                         x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                 px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16
                                 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0
                                 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid
                                  x-d-route x-rt">
                        <p style="margin:0px;">We store historical data for the past 12 months</p>
                    </div>
                </div>
            </div>
            <div
                    class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box
                            px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P
                            px_-p-0_10px_20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px
                            _smpx_-flex-basis-50P _smpx_-max-width-50P _mdpx_-flex-basis-33p33333333333333P
                            _mdpx_-max-width-33p33333333333333P
                            _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4 class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word
                            px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb27__27__27
                             px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22
                             _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                        TOP Cars and Owners</h4>
                    <div
                            class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block px_-max-width-360 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                        <img
                                src="{{ url('/img/design/black_car.jpg') }}"
                                class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P
                                            px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0
                                            px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14
                                            _lgpx_-fs-14 x-d-ux
                                            x-d-aid x-d-page x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                             _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                        <p
                                style="margin:0px;">Multi factors model helps to select the best
                            "performers" at the territory</p>
                    </div>
                </div>
            </div>
            <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box
                            px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px
                            px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                            _smpx_-p-0_20px_40px _smpx_-flex-basis-50P _smpx_-max-width-50P
                             _mdpx_-flex-basis-33p33333333333333P
                            _mdpx_-max-width-33p33333333333333P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4
                            class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb27__27__27 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                        Price/Day and Extras</h4>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block px_-max-width-360 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                        <img

                                src="{{ url('/img/design/prices.jpg') }}"
                                class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0
                                        px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif
                            _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                        <p
                                style="margin:0px;">Efficient pricing for every car category and model</p>
                    </div>
                </div>
            </div>
            <div class="x-el x-el-div px_-text-transform-uppercase
                     px_-box-sizing-border-box px_-flex-grow-1
                     px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px
                     px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif
                     px_-fs-14 _smpx_-p-0_20px_40px _smpx_-flex-basis-50P _smpx_-max-width-50P
                     _mdpx_-flex-basis-33p33333333333333P _mdpx_-max-width-33p33333333333333P
                     _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4
                            class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb27__27__27 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                        Market Saturation</h4>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block px_-max-width-360 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                        <img
                                src="{{ url('/img/design/map.jpg') }}"
                                class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0 px_-mr-0
                                         px_-mt-0 px_-mb-0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                        <p
                                style="margin:0px;">The unique technology picks up every data point on Turo
                            listings in the world</p>
                    </div>
                </div>
            </div>
            <div
                    class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_20px px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-p-0_20px_40px _smpx_-flex-basis-50P _smpx_-max-width-50P _mdpx_-flex-basis-33p33333333333333P _mdpx_-max-width-33p33333333333333P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <div
                        class="x-el x-el-div px_-text-transform-uppercase px__CA__nth-childn-mb-20px px___CA__last-child-mb-0__important px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                    <h4
                            class="x-el x-el-h4 px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-fs-20 px_-c-rgb27__27__27 px_-fw-400 px_-lh-1p25 px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-22 _lgpx_-fs-22 x-d-ux x-d-aid x-d-route">
                        Custom Car Model Report</h4>
                    <div class="x-el x-el-div px_-text-transform-uppercase px_-d-inline-block px_-max-width-360 px_-h-auto px_-cursor-auto px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                        <img
                                src="{{ url('/img/design/salon.jpg') }}"
                                class="x-el x-el-img px_-text-transform-uppercase px_-max-width-100P px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-0 px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid x-d-page x-d-section-jump">
                    </div>
                    <div class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb94__94__94 px_-fs-16 px_-fw-400 px_-lh-1p5 px_-mt-0 px_-mb-0 px_-ff-_Montserrat___arial__sans-serif _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route x-rt">
                        <p
                                style="margin:0px;">We provide custom reports for your choice based on your
                            requested model</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>