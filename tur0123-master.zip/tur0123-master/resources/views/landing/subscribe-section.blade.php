<div
        id="e35119ee-fbb7-406b-b4d8-a26ea0cbd6b0" class="widget widget-subscribe widget-subscribe-subscribe-1">
    <section class="x-el x-el-section px_-text-transform-uppercase px_-bc-rgb246__246__246 px_-pt-40px px_-pb-40px
            px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-pt-60px _mdpx_-pb-60px _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
        <div class="x-el x-el-div px_-text-transform-uppercase px_-ml-auto px_-mr-auto px_-pl-20px px_-pr-20px
                px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-w-728px _mdpx_-w-984px
                _mdpx_-fs-14 _lgpx_-w-1160px _lgpx_-fs-14 x-d-ux">
            <div class="x-el x-el-div px_-text-transform-uppercase px_-mt--5px px_-ff-_Archivo_Black___arial__sans-serif
                     px_-fs-14 _mdpx_-mt-0 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                <h3 class="x-el x-el-h3 px_-text-transform-uppercase px_-overflow-wrap-break-word
                        px_-word-wrap-break-word px_-word-break-break-word px_-fs-23 px_-c-rgb21__21__21 px_-fw-400 px_-lh-1p25
                        px_-ml-0 px_-mr-0 px_-mt-0 px_-mb-12px px_-ff-_Archivo_Black___arial__sans-serif px_-text-align-center
                        _mdpx_-fs-26 _lgpx_-fs-28 x-d-ux x-d-aid x-d-route">
                    Ready to get the most trusted data?</h3>
                <span class="x-el x-el-span px_-text-transform-uppercase px_-ff-_Archivo_Black___arial__sans-serif
                        px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                    <span class="x-el x-el-span px_-text-transform-uppercase
                                    px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                        <p class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16
                                        px_-fw-400 px_-lh-1p5 px_-mt-12px px_-mb-12px px_-ff-_Montserrat___arial__sans-serif
                                        px_-text-align-center _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route">
                                            Sign up to get the latest updates
                                        </p>
                                        <div class="x-el x-el-div px_-text-transform-uppercase px_-d-flex
                                        px_-box-sizing-border-box px_-flex-direction-row px_-flex-wrap-wrap px_-m-0_-10px_0
                                        px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _smpx_-m-0_-20px_0 _mdpx_-fs-14
                                        _lgpx_-fs-14 x-d-ux">
                                            <div class="x-el x-el-div px_-text-transform-uppercase px_-box-sizing-border-box
                                            px_-flex-grow-1 px_-flex-shrink-1 px_-flex-basis-100P px_-p-0_10px_0
                                            px_-max-width-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                            _smpx_-p-0_20px_0 _mdpx_-ml-16p666666666666664P _mdpx_-flex-basis-66p66666666666666P
                                             _mdpx_-max-width-66p66666666666666P _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
                                                <form method="post"
                                                      id="js-land-subscription-form"
                                                      action="{{ url('/subscribe') }}"
                                                      class="x-el x-el-form px_-text-transform-uppercase px_-mb-0 px_-d-flex
                                                px_-flex-direction-column px_-justify-content-center
                                                px_-align-items-center px_-text-align-center
                                                px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                                _mdpx_-flex-direction-row _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                                <div class="x-el x-el-div px_-text-transform-uppercase px_-mb-10px
                                                px_-w-100P px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14
                                                _mdpx_-flex-grow-1 _mdpx_-w-auto _mdpx_-pr-20px _mdpx_-mb-0 _mdpx_-fs-14
                                                _lgpx_-fs-14 x-d-ux x-d-route">
                                                <div class="x-el x-el-div px_-text-transform-uppercase
                                                px_-position-relative px_-ff-_Archivo_Black___arial__sans-serif
                                                px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                                {{csrf_field()}}
                                                    <input
                                                            type="email"
                                                            id="js-land-subscribe_email"
                                                            required
                                                            placeholder="Email Address"
                                                            class="x-el x-el-input px_-text-transform-none
                                                px_-bc-rgb255__255__255
                                                px_-border-color-rgb218__218__218 px_-c-rgb71__71__71
                                                px_-fs-12 px_-fw-400 px_-border-width-1px
                                                px_-w-100P px_-ff-_Montserrat___arial__sans-serif
                                                px_-border-radius-4px px_-pt-10px px_-pb-10px px_-pl-10px
                                                px_-pr-10px px_-border-style-solid
                                                px___placeholder-c-rgba71__71__71__0p7
                                                px__focus-outline-none
                                                px___-webkit-input-placeholder-c-rgba71__71__71__0p7
                                                px__-ms-input-placeholder-c-rgba71__71__71__0p7
                                                _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-aid">
                                                </div>
                                                </div>
                                                <div class="x-el x-el-div px_-text-transform-uppercase px_-w-100P
                                                px_-ff-_Archivo_Black___arial__sans-serif px_-fs-14 _mdpx_-w-auto
                                                _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux x-d-route">
                                                <div class="x-el x-el-div px_-text-transform-uppercase
                                                px_-position-relative px_-ff-_Archivo_Black___arial__sans-serif
                                                px_-fs-14 _mdpx_-fs-14 _lgpx_-fs-14 x-d-ux">
                                                <button
                                                        id="subscribe-form-submit"
                                                        type="submit"
                                                        class="x-el x-el-button px_-text-transform-uppercase
                                                px_-c-rgb0__0__0 px_-fw-700 px_-pt-10px px_-pb-10px
                                                px_-pl-30px px_-pr-30px px_-fs-12 px_-bc-rgb162__147__138
                                                px_-border-style-none px_-d-inline-block
                                                px_-letter-spacing-1px px_-text-align-center
                                                px_-text-decoration-none px_-w-100P
                                                px_-ff-_Montserrat___arial__sans-serif
                                                px_-border-radius-1000px px__hover-bc-rgb176__160__150
                                                px__focus-outline-none _smpx_-w-auto _mdpx_-pt-10px
                                                _mdpx_-pb-10px _mdpx_-pl-50px _mdpx_-pr-50px _mdpx_-fs-12
                                                _lgpx_-fs-14 x-d-ux x-d-aid">
                                                Subscribe
                                                </button>
                                                </div>
                                                </div>
                                                </form>
                                                {{--<button class="cta-modal-button show-sign-up-modal">Sign up</button>--}}
                                                <p class="x-el x-el-p px_-text-transform-none px_-overflow-wrap-break-word
                                        px_-word-wrap-break-word px_-word-break-break-word px_-c-rgb87__87__87 px_-fs-16
                                        px_-fw-400 px_-lh-1p5 px_-mt-12px px_-mb-12px px_-ff-_Montserrat___arial__sans-serif
                                        px_-text-align-center _mdpx_-fs-16 _lgpx_-fs-16 x-d-ux x-d-aid x-d-route"
                                                   id="js-subscribe-res-message"></p>
                                            </div>
                                    </span>
                                </span>
            </div>
        </div>
    </section>
</div>
