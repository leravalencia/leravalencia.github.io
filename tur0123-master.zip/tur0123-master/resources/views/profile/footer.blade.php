<footer class="clearfix padding bg_#161616 c_#f7f7f7">
    <div>{{ env('APP_NAME') }} &copy; 2018</div>
    <div>
        Access member-only data.
        {{env('APP_NAME')}} Methodology and get the latest updates
        <a href="{{ url('/login') }}">Sign In</a>
    </div>
</footer>