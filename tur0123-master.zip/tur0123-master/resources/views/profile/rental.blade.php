@extends('layouts.profile')
@section('main')
    @include('profile.components.header-with-buy-button', ['header'=>'Rental Analysis'])
    <div id="js-rental-holder" class="top-space bottom-space">
        <div class='tableauPlaceholder' id='viz1518604458462' style='position: relative'>
            <noscript><a href='#'><img alt='11_Delivery '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis_3&#47;11_Delivery&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='RentalAnalysis_3&#47;11_Delivery'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis_3&#47;11_Delivery&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>

        <div class='tableauPlaceholder' id='viz1518604526974' style='position: relative'>
            <noscript><a href='#'><img alt='10_Extras '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis_2&#47;10_Extras&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='RentalAnalysis_2&#47;10_Extras'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis_2&#47;10_Extras&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>
        <div class='tableauPlaceholder' id='viz1518604583988' style='position: relative'>
            <noscript><a href='#'><img alt='9_Average Daily Rates by Makes '
                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis&#47;9_AverageDailyRatesbyMakes&#47;1_rss.png'
                                       style='border: none'/></a></noscript>
            <object class='tableauViz' style='display:none;'>
                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                <param name='embed_code_version' value='3'/>
                <param name='site_root' value=''/>
                <param name='name' value='RentalAnalysis&#47;9_AverageDailyRatesbyMakes'/>
                <param name='tabs' value='no'/>
                <param name='toolbar' value='yes'/>
                <param name='static_image'
                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Re&#47;RentalAnalysis&#47;9_AverageDailyRatesbyMakes&#47;1.png'/>
                <param name='animate_transition' value='yes'/>
                <param name='display_static_image' value='yes'/>
                <param name='display_spinner' value='yes'/>
                <param name='display_overlay' value='yes'/>
                <param name='display_count' value='yes'/>
            </object>
        </div>
    </div>

    <script type='text/javascript'>
      let width = document.getElementById('js-rental-holder').offsetWidth;

      var divElement = document.getElementById('viz1518604458462');
      var vizElement = divElement.getElementsByTagName('object')[0];
      vizElement.style.width = width + 'px';
      vizElement.style.height = '877px';
      var scriptElement = document.createElement('script');
      scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
      vizElement.parentNode.insertBefore(scriptElement, vizElement);


      var divElementTwo = document.getElementById('viz1518604526974');
      var vizElementTwo = divElementTwo.getElementsByTagName('object')[0];
      vizElementTwo.style.width = width + 'px';
      vizElementTwo.style.height = '877px';
      vizElementTwo.parentNode.insertBefore(scriptElement, vizElementTwo);


      var divElementThree = document.getElementById('viz1518604583988');
      var vizElementThree = divElementThree.getElementsByTagName('object')[0];
      vizElementThree.style.width = width + 'px';
      vizElementThree.style.height = '877px';
      vizElementThree.parentNode.insertBefore(scriptElement, vizElementThree);
    </script>
    <style>.tableauPlaceholder iframe {
            overflow: auto;
        }</style>
@endsection