@extends('layouts.profile')
@section('main')
    <h1 class="align-center quarter-bottom-space">Profile</h1>
    <table>
        <tr>
            <td>Name</td>
            <td>{{auth()->user()->name}}</td>
        </tr>
        <tr>
            <td>Last Name</td>
            <td><{{auth()->user()->last_name}}/td>
        </tr>
        <tr>
            <td>Email</td>
            <td>{{auth()->user()->email}}</td>
        </tr>
    </table>
@endsection