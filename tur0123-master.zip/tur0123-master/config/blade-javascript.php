<?php

return [
    'namespace' => 'tour',
];
